#!/bin/bash

export FROG=dimitri
